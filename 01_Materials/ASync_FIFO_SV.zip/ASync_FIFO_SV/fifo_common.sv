class fifo_common;
	static string testname;
	static mailbox gen2bfm_wr=new();
	static mailbox gen2bfm_rd=new();
	static semaphore smp = new(1);
	static event e;
	static int bfm_count;
	static int wr_count=5;
	static int rd_count=5;
	static mailbox mon2cov_wr=new();
	static mailbox mon2cov_rd=new();
	static mailbox mon2sbd_wr=new();
	static mailbox mon2sbd_rd=new();
	static int num_matches;
	static int num_mismatches;
endclass
