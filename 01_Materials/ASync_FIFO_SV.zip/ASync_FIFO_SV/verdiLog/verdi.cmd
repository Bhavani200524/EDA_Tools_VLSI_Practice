simSetSimulator "-vcssv" -exec "/home/vvsainath/Desktop/ASync_FIFO_SV/simv" -args \
           "+testname=test_wr"
debImport "-dbdir" "/home/vvsainath/Desktop/ASync_FIFO_SV/simv.daidir"
debLoadSimResult /home/vvsainath/Desktop/ASync_FIFO_SV/async_fifo.fsdb
wvCreateWindow
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
verdiSetActWin -win $_nWave2
wvRestoreSignal -win $_nWave2 \
           "/home/vvsainath/Desktop/ASync_FIFO_SV/async_signal.rc" \
           -overWriteAutoAlias on -appendSignals on
wvSelectGroup -win $_nWave2 {WRITES}
wvSetCursor -win $_nWave2 24.596471 -snap {("WRITES" 3)}
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSetCursor -win $_nWave2 22.900162 -snap {("WRITES" 3)}
wvSelectSignal -win $_nWave2 {( "WRITES" 3 )} 
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSetSearchMode -win $_nWave2 -posedge
wvSetCursor -win $_nWave2 24.172394 -snap {("WRITES" 3)}
wvSearchNext -win $_nWave2
wvSetCursor -win $_nWave2 23.748316 -snap {("WRITES" 3)}
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSetCursor -win $_nWave2 84.815416 -snap {("WRITES" 4)}
srcActiveTrace "top.dut.wdata_i\[7:0\]" -TraceByDConWave -TraceTime 75 \
           -TraceValue 00000000 -win $_nTrace1
debReload
wvSetCursor -win $_nWave2 84.815416 -snap {("WRITES" 3)}
srcActiveTrace "top.dut.wr_en_i" -TraceByDConWave -TraceTime 75 -TraceValue 0 \
           -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcSelect -word -line 19 -pos 2 -win $_nTrace1
srcAction -pos 19 2 8 -win $_nTrace1 -name "vif.wr_en_i" -ctrlKey off
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
srcDeselectAll -win $_nTrace1
srcSelect -signal "wr_en_i" -line 2 -pos 1 -win $_nTrace1
srcAction -pos 1 3 1 -win $_nTrace1 -name "wr_en_i" -ctrlKey off
srcDeselectAll -win $_nTrace1
srcSelect -signal "tx.wr_en" -line 20 -pos 1 -win $_nTrace1
srcAction -pos 19 6 3 -win $_nTrace1 -name "tx.wr_en" -ctrlKey off
srcDeselectAll -win $_nTrace1
srcSelect -signal "wr_en" -line 11 -pos 1 -win $_nTrace1
srcAction -pos 10 5 3 -win $_nTrace1 -name "wr_en" -ctrlKey off
wvSetCursor -win $_nWave2 83.543185 -snap {("WRITES" 3)}
srcActiveTrace "top.dut.wr_en_i" -TraceByDConWave -TraceTime 75 -TraceValue 0 \
           -win $_nTrace1
verdiSetActWin -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSetCursor -win $_nWave2 25.020548 -snap {("WRITES" 3)}
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchPrev -win $_nWave2
wvSearchPrev -win $_nWave2
wvSetSearchMode -win $_nWave2 -posedge
wvSelectSignal -win $_nWave2 {( "WRITES" 3 )} 
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchPrev -win $_nWave2
wvSearchPrev -win $_nWave2
wvSearchPrev -win $_nWave2
wvSearchPrev -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSetCursor -win $_nWave2 334.596815 -snap {("WRITES" 5)}
wvSelectSignal -win $_nWave2 {( "WRITES" 5 )} 
wvSetCursor -win $_nWave2 345.622819 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 346.046897 -snap {("WRITES" 1)}
wvSetCursor -win $_nWave2 344.774665 -snap {("WRITES" 3)}
wvSetCursor -win $_nWave2 343.926511 -snap {("WRITES" 3)}
wvSelectSignal -win $_nWave2 {( "WRITES" 3 )} 
wvSetCursor -win $_nWave2 344.774665 -snap {("WRITES" 3)}
wvSetCursor -win $_nWave2 343.926511 -snap {("WRITES" 5)}
wvSetCursor -win $_nWave2 344.350588 -snap {("WRITES" 5)}
wvSetCursor -win $_nWave2 346.046897 -snap {("WRITES" 3)}
wvSelectSignal -win $_nWave2 {( "WRITES" 5 )} 
wvSelectSignal -win $_nWave2 {( "WRITES" 3 )} 
wvSelectSignal -win $_nWave2 {( "WRITES" 6 )} 
wvSetCursor -win $_nWave2 345.622819 -snap {("WRITES" 1)}
wvSelectSignal -win $_nWave2 {( "WRITES" 1 )} 
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSetCursor -win $_nWave2 375.732292 -snap {("WRITES" 1)}
wvSetCursor -win $_nWave2 385.486065 -snap {("WRITES" 1)}
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSetCursor -win $_nWave2 335.718070 -snap {("WRITES" 5)}
wvSetCursor -win $_nWave2 345.047766 -snap {("WRITES" 3)}
wvSetCursor -win $_nWave2 364.131235 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 384.486935 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 404.418557 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 423.926103 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 445.129957 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 464.213425 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 484.145048 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 506.197056 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 335.718070 -snap {("WRITES" 5)}
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvZoomOut -win $_nWave2
wvSetCursor -win $_nWave2 333.173608 -snap {("WRITES" 5)}
wvZoomIn -win $_nWave2
wvZoomIn -win $_nWave2
wvZoomOut -win $_nWave2
wvSetCursor -win $_nWave2 324.843043 -snap {("WRITES" 3)}
wvSetCursor -win $_nWave2 335.869047 -snap {("WRITES" 5)}
wvSetCursor -win $_nWave2 334.596815 -snap {("WRITES" 5)}
srcActiveTrace "top.dut.full_o" -TraceByDConWave -TraceTime 5 -TraceValue 0 -win \
           $_nTrace1
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSetCursor -win $_nWave2 335.444970 -snap {("WRITES" 5)}
srcActiveTrace "top.dut.full_o" -TraceByDConWave -TraceTime 5 -TraceValue 0 -win \
           $_nTrace1
wvSetCursor -win $_nWave2 334.596815 -snap {("WRITES" 5)}
srcActiveTrace "top.dut.full_o" -TraceByDConWave -TraceTime 5 -TraceValue 0 -win \
           $_nTrace1
wvSetCursor -win $_nWave2 334.596815 -snap {("WRITES" 5)}
srcActiveTrace "top.dut.full_o" -TraceByDConWave -TraceTime 5 -TraceValue 0 -win \
           $_nTrace1
wvSetCursor -win $_nWave2 334.596815 -snap {("WRITES" 5)}
srcActiveTrace "top.dut.full_o" -TraceByDConWave -TraceTime 5 -TraceValue 0 -win \
           $_nTrace1
wvSetCursor -win $_nWave2 334.596815 -snap {("WRITES" 5)}
wvSetCursor -win $_nWave2 335.020892 -snap {("WRITES" 4)}
srcActiveTrace "top.dut.wdata_i\[7:0\]" -TraceByDConWave -TraceTime 325 \
           -TraceValue 00100100 -win $_nTrace1
wvSetCursor -win $_nWave2 334.596815 -snap {("WRITES" 5)}
srcActiveTrace "top.dut.full_o" -TraceByDConWave -TraceTime 5 -TraceValue 0 -win \
           $_nTrace1
wvSetCursor -win $_nWave2 325.691197 -snap {("WRITES" 5)}
srcActiveTrace "top.dut.full_o" -TraceByDConWave -TraceTime 5 -TraceValue 0 -win \
           $_nTrace1
wvSetCursor -win $_nWave2 324.418965 -snap {("WRITES" 5)}
srcActiveTrace "top.dut.full_o" -TraceByDConWave -TraceTime 5 -TraceValue 0 -win \
           $_nTrace1
wvSelectSignal -win $_nWave2 {( "WRITES" 5 )} 
wvSetCursor -win $_nWave2 346.470974 -snap {("WRITES" 5)}
srcActiveTrace "top.dut.full_o" -TraceByDConWave -TraceTime 335 -TraceValue 1 \
           -win $_nTrace1
wvSetCursor -win $_nWave2 346.470974 -snap {("WRITES" 5)}
wvSetCursor -win $_nWave2 339.685740 -snap {("WRITES" 6)}
srcActiveTrace "top.dut.wr_error_o" -TraceByDConWave -TraceTime 5 -TraceValue 0 \
           -win $_nTrace1
wvSetCursor -win $_nWave2 339.685740 -snap {("WRITES" 6)}
srcActiveTrace "top.dut.wr_error_o" -TraceByDConWave -TraceTime 5 -TraceValue 0 \
           -win $_nTrace1
wvSetCursor -win $_nWave2 339.685740 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 335.444970 -snap {("WRITES" 5)}
wvSetCursor -win $_nWave2 335.444970 -snap {("WRITES" 5)}
wvSetCursor -win $_nWave2 302.791034 -snap {("READS" 0)}
verdiDockWidgetSetCurTab -dock widgetDock_<Message>
verdiSetActWin -dock widgetDock_<Message>
nsMsgSelect -range {3 2-2}
nsMsgExpandItem -tab trace -index {3 2}
nsMsgExpandItem -tab trace -index {3 2 2}
nsMsgSelect -range {3 2 2 1-1}
nsMsgExpandItem -tab trace -index {3 2 2 1}
nsMsgExpandItem -tab trace -index {3 2 2 1 3}
nsMsgSelect -range {3 2 2 1 3 1-1}
nsMsgExpandItem -tab trace -index {3 2 2 1 3 1}
nsMsgExpandItem -tab trace -index {3 2 2 1 3 1 2}
nsMsgSelect -range {3 2 2 1 3 1 2 0-0}
nsMsgExpandItem -tab trace -index {3 2 2 1 3 1 2 0}
nsMsgCollapseItem -tab trace -index {3 2 2 1 3 1 2}
nsMsgCollapseItem -tab trace -index {3 2 2 1 3 1}
nsMsgCollapseItem -tab trace -index {3 2 2 1 3}
verdiDockWidgetSetCurTab -dock windowDock_nWave_2
verdiSetActWin -win $_nWave2
wvSetCursor -win $_nWave2 335.020892 -snap {("WRITES" 5)}
srcActiveTrace "top.dut.full_o" -TraceByDConWave -TraceTime 5 -TraceValue 0 -win \
           $_nTrace1
verdiDockWidgetSetCurTab -dock widgetDock_<Message>
verdiSetActWin -dock widgetDock_<Message>
nsMsgExpandItem -tab trace -index {4 0}
nsMsgSelect -range {4 0-0}
nsMsgSelect -range {4-4}
nsMsgExpandItem -tab trace -index {4 0 0}
nsMsgSelect -range {4 0 0 1-1}
nsMsgCollapseItem -tab trace -index {4 0 0}
nsMsgSelect -range {4 1-1}
nsMsgSelect -range {4 2-2}
nsMsgExpandItem -tab trace -index {4 2}
nsMsgExpandItem -tab trace -index {4 2 0}
nsMsgSelect -range {4 2 0 0-0}
nsMsgExpandItem -tab trace -index {4 2 0 1}
nsMsgSelect -range {4 2 0 1 0-0}
nsMsgExpandItem -tab trace -index {4 2 1}
nsMsgSelect -range {4 2 1 0-0}
nsMsgExpandItem -tab trace -index {4 2 1 1}
nsMsgSelect -range {4 2 1 1 0-0}
nsMsgExpandItem -tab trace -index {4 2 2}
nsMsgSelect -range {4 2 2 1-1}
nsMsgExpandItem -tab trace -index {4 2 2 1}
nsMsgSelect -range {4 2 2 1 3-3}
nsMsgExpandItem -tab trace -index {4 2 3}
nsMsgSelect -range {4 2 3 1-1}
nsMsgExpandItem -tab trace -index {4 2 3 1}
nsMsgExpandItem -tab trace -index {4 2 3 1 2}
nsMsgSelect -range {4 2 3 1 2 0-0}
nsMsgSelect -range {4 2 3 1 2-2}
nsMsgExpandItem -tab trace -index {4 2 3 1 3}
nsMsgSelect -range {4 2 3 1 3 2-2}
nsMsgExpandItem -tab trace -index {4 2 3 1 3 2}
nsMsgExpandItem -tab trace -index {4 2 3 1 3 2 2}
nsMsgSelect -range {4 2 3 1 3 2 2 0-0}
nsMsgCollapseItem -tab trace -index {4 2 3 1 3 2 2}
nsMsgCollapseItem -tab trace -index {4 2}
nsMsgCollapseItem -tab trace -index {4 0}
nsMsgExpandItem -tab trace -index {4 0}
nsMsgCollapseItem -tab trace -index {4 0}
nsMsgExpandItem -tab trace -index {4 2}
nsMsgSelect -range {4 2 0 1 0-0}
nsMsgSelect -range {4 2 3 1 3 2 2-2}
nsMsgExpandItem -tab trace -index {4 2 3 1 3 2 3}
nsMsgSelect -range {4 2 3 1 3 2 3 2-2}
nsMsgExpandItem -tab trace -index {4 2 3 1 3 2 3 2}
nsMsgExpandItem -tab trace -index {4 2 3 1 3 2 3 2 0}
nsMsgSelect -range {4 2 3 1 3 2 3 2 0 0-0}
nsMsgExpandItem -tab trace -index {4 2 3 1 3 2 3 2 0 0}
nsMsgExpandItem -tab trace -index {4 2 3 1 3 2 3 2 0 0 0}
nsMsgSelect -range {4 2 3 1 3 2 3 2 0 0 0 0-0}
nsMsgCollapseItem -tab trace -index {4 2 3 1 3 2 3 2 0 0 0}
nsMsgCollapseItem -tab trace -index {4 2 3 1 3 2 3 2 0 0}
nsMsgCollapseItem -tab trace -index {4 2 3 1 3 2 3 2 0}
nsMsgCollapseItem -tab trace -index {4 2 3 1 3 2 3 2}
nsMsgCollapseItem -tab trace -index {4 2 3 1 3 2 3}
nsMsgCollapseItem -tab trace -index {4 2 3 1 3 2}
nsMsgCollapseItem -tab trace -index {4 2 3 1 3}
nsMsgCollapseItem -tab trace -index {4 2 3 1 2}
srcHBSelect "top.dut" -win $_nTrace1
verdiSetActWin -dock widgetDock_<Inst._Tree>
verdiDockWidgetSetCurTab -dock windowDock_nWave_2
verdiSetActWin -win $_nWave2
debReload
wvSetCursor -win $_nWave2 25.444625 -snap {("WRITES" 4)}
wvSetCursor -win $_nWave2 115.348966 -snap {("WRITES" 4)}
wvSelectGroup -win $_nWave2 {READS}
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvSetCursor -win $_nWave2 114.500811 -snap {("READS" 3)}
srcActiveTrace "top.dut.rdata_o\[7:0\]" -TraceByDConWave -TraceTime 5 -TraceValue \
           00000000 -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcSelect -signal "rdata_o" -line 34 -pos 1 -win $_nTrace1
srcAction -pos 33 3 3 -win $_nTrace1 -name "rdata_o" -ctrlKey off
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
srcDeselectAll -win $_nTrace1
srcSelect -signal "rdata_o" -line 34 -pos 1 -win $_nTrace1
srcAction -pos 33 3 3 -win $_nTrace1 -name "rdata_o" -ctrlKey off
srcSetOptions -annotate on -win $_nTrace1
schSetOptions -win $_nSchema1 -annotate on
wvSetCursor -win $_nWave2 4.240771 -snap {("READS" 3)}
srcActiveTrace "top.dut.rdata_o\[7:0\]" -TraceByDConWave -TraceTime 0 -TraceValue \
           xxxxxxxx -win $_nTrace1
verdiSetActWin -win $_nWave2
srcDeselectAll -win $_nTrace1
srcSelect -signal "rdata_o" -line 34 -pos 1 -win $_nTrace1
srcAction -pos 33 3 2 -win $_nTrace1 -name "rdata_o" -ctrlKey off
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
wvSetCursor -win $_nWave2 174.295679 -snap {("READS" 1)}
srcActiveTrace "top.dut.rd_clk_i" -TraceByDConWave -TraceTime 168 -TraceValue 0 \
           -win $_nTrace1
verdiSetActWin -win $_nWave2
wvSetCursor -win $_nWave2 177.264219 -snap {("READS" 3)}
srcActiveTrace "top.dut.rdata_o\[7:0\]" -TraceByDConWave -TraceTime 5 -TraceValue \
           00000000 -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcSelect -signal "rdata_o" -line 34 -pos 1 -win $_nTrace1
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
srcDeselectAll -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcSelect -signal "rdata_o" -line 34 -pos 1 -win $_nTrace1
srcDeselectAll -win $_nTrace1
srcSelect -signal "rd_toggle_f" -line 93 -pos 1 -win $_nTrace1
srcAction -pos 92 6 4 -win $_nTrace1 -name "rd_toggle_f" -ctrlKey off
srcDeselectAll -win $_nTrace1
debReload
verdiSetActWin -win $_nWave2
wvScrollUp -win $_nWave2 5
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 25.444625 -snap {("WRITES" 4)}
wvSetCursor -win $_nWave2 44.528093 -snap {("WRITES" 4)}
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 49.617018 -snap {("READS" 4)}
wvSetCursor -win $_nWave2 77.606105 -snap {("READS" 2)}
wvSetCursor -win $_nWave2 104.322961 -snap {("READS" 2)}
wvSetCursor -win $_nWave2 133.160203 -snap {("READS" 3)}
wvSetCursor -win $_nWave2 20.355700 -snap {("READS" 2)}
wvSetCursor -win $_nWave2 49.192941 -snap {("READS" 2)}
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 32.653935 -snap {("READS" 4)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSetCursor -win $_nWave2 19.507546 -snap {("READS" 2)}
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 49.617018 -snap {("READS" 2)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 75.909797 -snap {("READS" 2)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSetCursor -win $_nWave2 114.076734 -snap {("WRITES" 4)}
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 119.165659 -snap {("READS" 3)}
wvSetCursor -win $_nWave2 148.426978 -snap {("READS" 3)}
wvSetCursor -win $_nWave2 176.416065 -snap {("READS" 3)}
wvSetCursor -win $_nWave2 203.132921 -snap {("READS" 3)}
wvSetCursor -win $_nWave2 231.122008 -snap {("READS" 3)}
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSetCursor -win $_nWave2 24.596471 -snap {("WRITES" 3)}
wvSelectSignal -win $_nWave2 {( "WRITES" 3 )} 
wvSetSearchMode -win $_nWave2 -posedge
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvSearchNext -win $_nWave2
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 50.041095 -snap {("WRITES" 4)}
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 47.072556 -snap {("WRITES" 4)}
wvSetCursor -win $_nWave2 66.156024 -snap {("WRITES" 4)}
wvSetCursor -win $_nWave2 272.257485 -snap {("READS" 3)}
wvSetCursor -win $_nWave2 84.391339 -snap {("WRITES" 4)}
wvSetCursor -win $_nWave2 301.518803 -snap {("READS" 3)}
wvSetCursor -win $_nWave2 104.747039 -snap {("WRITES" 4)}
wvSetCursor -win $_nWave2 329.931967 -snap {("READS" 3)}
wvSetCursor -win $_nWave2 124.678661 -snap {("WRITES" 4)}
wvSetCursor -win $_nWave2 356.224746 -snap {("READS" 3)}
wvSetCursor -win $_nWave2 144.186207 -snap {("WRITES" 4)}
wvSetCursor -win $_nWave2 384.637911 -snap {("READS" 3)}
wvSetCursor -win $_nWave2 164.965984 -snap {("WRITES" 4)}
wvSetCursor -win $_nWave2 413.899229 -snap {("READS" 3)}
wvSetCursor -win $_nWave2 184.473529 -snap {("WRITES" 4)}
wvSetCursor -win $_nWave2 441.040162 -snap {("READS" 3)}
wvSetCursor -win $_nWave2 204.914045 -snap {("WRITES" 4)}
wvSetCursor -win $_nWave2 469.114065 -snap {("READS" 3)}
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 483.108608 -snap {("READS" 4)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSetCursor -win $_nWave2 335.869047 -snap {("WRITES" 5)}
wvSetCursor -win $_nWave2 344.774665 -snap {("WRITES" 6)}
wvSelectSignal -win $_nWave2 {( "WRITES" 3 )} 
wvSetCursor -win $_nWave2 346.046897 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 363.434057 -snap {("WRITES" 3)}
wvSetCursor -win $_nWave2 385.061988 -snap {("WRITES" 3)}
wvSetCursor -win $_nWave2 403.721379 -snap {("WRITES" 3)}
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvSetCursor -win $_nWave2 860.706840 -snap {("READS" 4)}
wvSetCursor -win $_nWave2 874.701383 -snap {("READS" 5)}
wvSetCursor -win $_nWave2 900.994162 -snap {("READS" 5)}
wvSetCursor -win $_nWave2 932.375866 -snap {("READS" 5)}
wvSetCursor -win $_nWave2 957.820491 -snap {("READS" 5)}
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvZoom -win $_nWave2 0.000000 350.900735
wvSetCursor -win $_nWave2 245.759522 -snap {("READS" 4)}
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSetCursor -win $_nWave2 54.505721 -snap {("WRITES" 6)}
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvSetCursor -win $_nWave2 344.084487 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 365.693264 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 384.721889 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 405.040589 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 424.391733 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 445.355472 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 463.416539 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 484.380278 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 505.344016 -snap {("WRITES" 6)}
wvSetCursor -win $_nWave2 335.053954 -snap {("WRITES" 5)}
wvSetCursor -win $_nWave2 344.729526 -snap {("WRITES" 4)}
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvSetCursor -win $_nWave2 957.555404 -snap {("READS" 4)}
wvSetCursor -win $_nWave2 974.326395 -snap {("READS" 5)}
wvSetCursor -win $_nWave2 1001.417996 -snap {("READS" 5)}
wvSetCursor -win $_nWave2 1029.477154 -snap {("READS" 5)}
wvSetCursor -win $_nWave2 1055.278679 -snap {("READS" 5)}
wvSetCursor -win $_nWave2 1083.642397 -snap {("READS" 5)}
wvSetCursor -win $_nWave2 1112.669112 -snap {("READS" 5)}
wvSetCursor -win $_nWave2 1140.728270 -snap {("READS" 5)}
wvSetCursor -win $_nWave2 1168.464909 -snap {("READS" 5)}
wvSetCursor -win $_nWave2 1197.169105 -snap {("READS" 5)}
wvScrollUp -win $_nWave2 1
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvSetCursor -win $_nWave2 340.677774 -snap {("WRITES" 6)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvZoom -win $_nWave2 0.000000 485.068663
wvZoom -win $_nWave2 0.000000 435.135124
wvSetCursor -win $_nWave2 333.630258 -snap {("WRITES" 5)}
wvSetCursor -win $_nWave2 344.828588 -snap {("WRITES" 4)}
wvSetCursor -win $_nWave2 364.825607 -snap {("WRITES" 4)}
wvSetCursor -win $_nWave2 383.622804 -snap {("WRITES" 4)}
wvSetCursor -win $_nWave2 404.819644 -snap {("WRITES" 4)}
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvSetCursor -win $_nWave2 334.519695 -snap {("WRITES" 5)}
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 344.518204 -snap {("READS" 3)}
wvSetCursor -win $_nWave2 370.514328 -snap {("READS" 3)}
wvSetCursor -win $_nWave2 370.114388 -snap {("WRITES" 5)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 370.514328 -snap {("READS" 3)}
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvSetCursor -win $_nWave2 763.575725 -snap {("READS" 3)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 1119.291045
wvSetCursor -win $_nWave2 733.839332 -snap {("READS" 3)}
wvSetCursor -win $_nWave2 762.635039 -snap {("READS" 3)}
wvSetCursor -win $_nWave2 777.432833 -snap {("READS" 4)}
wvSetCursor -win $_nWave2 777.032892 -snap {("READS" 1)}
wvSetCursor -win $_nWave2 790.230925 -snap {("READS" 2)}
wvSetCursor -win $_nWave2 818.626691 -snap {("READS" 5)}
wvSetCursor -win $_nWave2 847.022457 -snap {("READS" 5)}
wvSetCursor -win $_nWave2 874.218403 -snap {("READS" 5)}
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 261.783088 -snap {("READS" 3)}
wvZoom -win $_nWave2 239.503676 328.621324
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvSetCursor -win $_nWave2 115.328720 -snap {("WRITES" 4)}
wvSetCursor -win $_nWave2 245.401168 -snap {("READS" 4)}
wvSetCursor -win $_nWave2 115.328720 -snap {("WRITES" 4)}
wvSetCursor -win $_nWave2 244.745891 -snap {("READS" 4)}
wvSetCursor -win $_nWave2 2829.319030
wvSetCursor -win $_nWave2 2989.372837
wvSetCursor -win $_nWave2 2989.372837
wvSetCursor -win $_nWave2 2990.355753
wvSetCursor -win $_nWave2 2991.011029
wvSetCursor -win $_nWave2 2991.011029
wvCenterMarker -win $_nWave2
wvGoToTime -win $_nWave2 2995
wvGoToTime -win $_nWave2 2989
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvSetCursor -win $_nWave2 244.900709 -snap {("READS" 2)}
wvSetCursor -win $_nWave2 231.139896 -snap {("READS" 2)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvSetCursor -win $_nWave2 104.999109 -snap {("WRITES" 3)}
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvSetCursor -win $_nWave2 231.467534 -snap {("READS" 2)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvGoToTime -win $_nWave2 245
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvGoToTime -win $_nWave2 245
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvSetCursor -win $_nWave2 5249.586397 -snap {("READS" 4)}
wvSetCursor -win $_nWave2 7491.452206 -snap {("READS" 4)}
wvSetCursor -win $_nWave2 9886.488971 -snap {("READS" 4)}
wvSetCursor -win $_nWave2 12225.827206 -snap {("READS" 4)}
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvSetCursor -win $_nWave2 1434.237132 -snap {("WRITES" 6)}
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvZoom -win $_nWave2 0.000000 3495.082721
wvZoom -win $_nWave2 0.000000 976.567231
wvZoom -win $_nWave2 0.000000 93.348338
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvSetCursor -win $_nWave2 32.946472 -snap {("WRITES" 4)}
wvZoom -win $_nWave2 0.000000 175.714519
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvDisplayGridCount -win $_nWave2 -off
wvGetSignalClose -win $_nWave2
wvReloadFile -win $_nWave2
wvZoomAll -win $_nWave2
wvZoom -win $_nWave2 0.000000 1072.911489
wvZoom -win $_nWave2 0.000000 166.656288
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvScrollDown -win $_nWave2 0
wvZoomOut -win $_nWave2
wvZoomOut -win $_nWave2
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollUp -win $_nWave2 1
wvScrollDown -win $_nWave2 1
wvScrollDown -win $_nWave2 1
debExit
