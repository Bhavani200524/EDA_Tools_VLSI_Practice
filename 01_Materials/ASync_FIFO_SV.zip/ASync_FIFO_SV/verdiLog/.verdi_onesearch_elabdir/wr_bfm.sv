class wr_bfm;
	wr_tx tx;
	virtual fifo_intf vif;
	task run();
		forever begin
			$display("\t\t\t wr_bfm run method called");
			vif=top.pif;
			//Get tx from mailbox
			tx=new();
			fifo_common::gen2bfm_wr.get(tx);
			// Drive the received tx to the RTL
			fifo_common::smp.get(1);
			drive_tx(tx);
			// Observe the outputs
			tx.print("WR_BFM");
			fifo_common::bfm_count++;
			fifo_common::smp.put(1);
			if(fifo_common::bfm_count == fifo_common::wr_count)begin
				->fifo_common::e;
			end

		end
	endtask

	task drive_tx(wr_tx tx);
		@(posedge vif.wr_clk_i);
		vif.wr_en_i	=	tx.wr_en;
		vif.wdata_i	=	tx.wdata;
		@(posedge vif.wr_clk_i);
		tx.full = vif.full_o;
		tx.wr_error = vif.wr_error_o;
		vif.wr_en_i	=	0;
		vif.wdata_i	=	0;
		repeat(tx.wr_delay)@(posedge vif.wr_clk_i);
	endtask
endclass
