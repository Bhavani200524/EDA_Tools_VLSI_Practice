class wr_tx;
	//Properties
	//bit wr_en_i   ; 
	//bit[7:0] wdata_i; 
	//bit rd_en_i   ; 
	//bit[7:0] rdata_o; 
	//bit full_o    ; 
	//bit empty_o   ; 
	//bit wr_error_o; 
	//bit rd_error_o;
	rand bit wr_en;
	rand bit [7:0] wdata;
	     bit full;
	     bit wr_error;
	rand int wr_delay;
	
	//Methods
	function void print(string name="WR_TX");
		$display("Time=%0t\tComp=%0s\tWr_en=%0d\tWdata=%0h\tFull=%0d\tWr_error=%0d",$time,name,wr_en,wdata,full,wr_error);
		//$display("##############################");
		//$display("Time\t=%0t",$time);
		//$display("Accesing Component	=%0s",name);
		//$display("WR_En\t=%0d",wr_en);
		//$display("Wdata\t=%0h",wdata);
		//$display("Full\t=%0d",full);
		//$display("Wr_Error=%0d",wr_error);
		//$display("##############################");
	endfunction
	//Constraints
	constraint wr_delay_c
	{
		soft wr_delay==0;
	}
endclass
