class wr_cov;
	wr_tx tx;
	// We will write coverpoints inside covergroup
	// We will write bins inside coverpoint
	// Covergroup is dynamic in nature
	covergroup wr_cg;
		WR_EN_CP:coverpoint tx.wr_en
		{
			bins WRITE = {1'b1};
			ignore_bins WRITE_IGN = {1'b0};
		}
		WDATA_CP:coverpoint tx.wdata
		{
			option.auto_bin_max=4;
		}
		FULL_CP: coverpoint tx.full
		{
			bins FULL_1 = {1'b1};
			bins FULL_0 = {1'b0};
		}
		WR_ERROR_CP: coverpoint tx.wr_error
		{
			bins WR_ERROR_1 = {1'b1};
			bins WR_ERROR_0 = {1'b0};
		}
	endgroup

	function new();
		wr_cg=new();
	endfunction
	task run();
		$display("\t\t\t wr_cov run method called");
		// Get the tx from monitor
		// Sample the coverage
		forever begin
			fifo_common::mon2cov_wr.get(tx);
			wr_cg.sample();
		end
	endtask
endclass
