class wr_gen;
	wr_tx tx;
	int delay;
	task run();
		$display("\t\t\t wr_gen run method called");
		case(fifo_common::testname)
			"test_wr":begin
				$display("Entered into Test_wr testcase");
				write(fifo_common::wr_count);
			end
			"test_full":begin
				write(fifo_common::wr_count);
			end
			"test_wr_error":begin
				write(fifo_common::wr_count);
			end
			"test_wr_rd":begin
				write(fifo_common::wr_count);
			end
			"test_full_error":begin
				write(fifo_common::wr_count);
			end
			"test_empty_error":begin
				write(fifo_common::wr_count);
			end
			"test_all_error":begin
				write(fifo_common::wr_count);
			end
			"test_concurrent_wr_rd":begin
				repeat(100)begin
					delay=$urandom_range(1,10);	
					write(fifo_common::wr_count,delay);
				end
			end
		endcase
	endtask
	task write(int count,int delay=0);
		repeat(count)begin
			tx=new();
			assert(tx.randomize() with {wr_en==1;wr_delay==delay;});
			fifo_common::gen2bfm_wr.put(tx);
			tx.print("WR_GEN");
		end
	endtask
endclass
