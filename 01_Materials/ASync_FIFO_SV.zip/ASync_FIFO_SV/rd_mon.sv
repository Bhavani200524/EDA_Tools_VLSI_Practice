class rd_mon;
	rd_tx tx;
	virtual fifo_intf vif;
	task run();
		forever begin
			//$display("\t\t\t rd_mon run method called");
			vif=top.pif;
			@(posedge vif.rd_clk_i);
			if(vif.rd_en_i==1)begin
				tx=new();
				//rand bit rd_en;
				//     bit [7:0] rdata;
				//     bit empty;
				//     bit rd_error;
				tx.rd_en = vif.rd_en_i;
				tx.rdata = vif.rdata_o;
				tx.empty = vif.empty_o;
				tx.rd_error = vif.rd_error_o;
				fifo_common::mon2cov_rd.put(tx);
				fifo_common::mon2sbd_rd.put(tx);
				tx.print("RD_MON");	
			end
		end
	endtask
endclass
