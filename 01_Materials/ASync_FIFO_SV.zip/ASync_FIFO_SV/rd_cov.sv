class rd_cov;
	rd_tx tx;
	// We will write coverpoints inside covergroup
	// We will write bins inside coverpoint
	// Covergroup is dynamic in nature
	covergroup rd_cg;
		RD_EN_CP:coverpoint tx.rd_en
		{
			bins READ = {1'b1};
			ignore_bins READ_IGN = {1'b0};
		}
		RDATA_CP:coverpoint tx.rdata
		{
			option.auto_bin_max=4;
		}
		EMPTY_CP: coverpoint tx.empty
		{
			bins EMPTY_1 = {1'b1};
			bins EMPTY_0 = {1'b0};
		}
		RD_ERROR_CP: coverpoint tx.rd_error
		{
			bins RD_ERROR_1 = {1'b1};
			bins RD_ERROR_0 = {1'b0};
		}
	endgroup

	function new();
		rd_cg=new();
	endfunction
	task run();
		$display("\t\t\t wr_cov run method called");
		// Get the tx from monitor
		// Sample the coverage
		forever begin
			fifo_common::mon2cov_rd.get(tx);
			rd_cg.sample();
		end
	endtask
endclass
