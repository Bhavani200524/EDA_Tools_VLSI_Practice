class rd_bfm;
	rd_tx tx;
	virtual fifo_intf vif;
	task run();
		//$display("Inside run task of read bfm");
		forever begin
			$display("\t\t\t rd_bfm run method called and inside forever loop");
			vif=top.pif;
			//Get tx from mailbox
			tx=new();
			//$display("Before getting the tx from the read gen",);
			fifo_common::gen2bfm_rd.get(tx);
			//$display("After getting the tx from the read gen",);
			// Drive the received tx to the RTL
			fifo_common::smp.get(1);
			drive_tx(tx);
			// Observe the outputs
			tx.print("RD_BFM");
			fifo_common::smp.put(1);
		end
	endtask

	task drive_tx(rd_tx tx);
		//$display("Inside Drive_tx task of read agent");
		@(posedge vif.rd_clk_i);
		vif.rd_en_i = tx.rd_en;
		@(posedge vif.rd_clk_i);
		tx.rdata = vif.rdata_o;
		tx.empty = vif.empty_o;
		tx.rd_error = vif.rd_error_o;
		vif.rd_en_i = 0;
		repeat(tx.rd_delay)@(posedge vif.rd_clk_i);
	endtask
endclass
