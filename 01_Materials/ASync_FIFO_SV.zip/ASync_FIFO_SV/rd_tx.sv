class rd_tx;
	//Properties
	//bit wr_en_i   ; 
	//bit[7:0] wdata_i; 
	//bit rd_en_i   ; 
	//bit[7:0] rdata_o; 
	//bit full_o    ; 
	//bit empty_o   ; 
	//bit wr_error_o; 
	//bit rd_error_o;
	rand bit rd_en;
	     bit [7:0] rdata;
	     bit empty;
	     bit rd_error;
	rand int rd_delay;
	
	//Methods
	function void print(string name="RD_TX");
		$display("Time=%0t\tComp=%0s\tRd_en=%0d\trdata=%0h\tEmpty=%0d\tRd_error=%0d",$time,name,rd_en,rdata,empty,rd_error);
		//$display("##############################");
		//$display("Time=%0t\t",$time);
		//$display("Accesing Component=%0s\t",name);
		//$display("RD_En=%0d\t",rd_en);
		//$display("Rdata=%0h\t",rdata);
		//$display("Empty=%0d\t",empty);
		//$display("Rd_Error=%0d\t",rd_error);
		//$display("##############################");
	endfunction
	//Constraints
	constraint rd_delay_c
	{
		soft rd_delay ==0;
	}
endclass
